#!/bin/bash
sudo npm install
sudo npx prisma db push
sudo npm run dev
